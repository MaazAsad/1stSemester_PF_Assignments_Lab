#include<iostream>
using namespace std;

int main()
{
  int day, month;
  cout << "Enter day(1-31): ";
  cin >> day;
  cout << "Enter month(1-12): ";
  cin >> month;

  if(month > 0 && month < 13 && day > 0 and day <32)
  {
    //winter
    if(month == 12 && day >16){
      cout << "Winter"<<endl;
    }
    if(month <3){
      cout << "Winter"<<endl;
    }
    if(month == 3 && day < 15){
      cout << "winter" <<endl;
    }

    //spring
    if(month == 3 && day > 15){
      cout << "Spring" <<endl;
    }
    if((month >3 && month <=6)){
      cout <<"Spring" <<endl;
    }
    if((month ==6 && day < 16)){
        cout <<"Spring" <<endl;
    }

    //summer
    if(month == 6 && day > 15){
      cout << "Summer" <<endl;
    }
    if((month >6 && month <=9)|| (month ==9 && day < 16)){
      cout <<"Summer" <<endl;
    }

    //fall
    if(month == 9&& day > 15){
      cout << "Fall" <<endl;
    }
    if((month >9 && month <=10) || (month ==10 && day < 16)){
      cout <<"Fall" <<endl;
    }
  }
  else
  {
    cout << "Invald output \n";
  }



  return 0;
}

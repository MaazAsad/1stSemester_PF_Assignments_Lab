#include<iostream>
#define PI 3.14159
using namespace std;

int main()
{ int cal,fat;
  float percentfat = -1;
  cout << "Enter calories in food: ";
  cin >> cal;
  cout << "Enter fats (in grams) in food: ";
  cin >> fat;



  if(cal > 0 && fat > 0  && (fat*9 < cal)){
    percentfat = (float(fat*9)/cal) * 100;
  }
  else{
    cout <<"valuse of calories or fats have been entered incorrectly!"<<endl;
  }

  if(percentfat != -1 && percentfat < 30){
    cout << "food is low in fat" << endl;
  }
  else if(percentfat != -1 && percentfat >=30){
    cout <<"food is high in fats" << endl;
  }





  return 0;
}

#include<iostream>
#include <iomanip>

using namespace std;

int main()
{
  int p1, p2;

  cout << "Enter " << endl
       << "1 for rock"<<endl
       << "2 for paper" << endl
       << "3 for scissors" << endl << endl;

  cout << "player 1 turn: ";
  cin >> p1;
  cout << "player 2 turn: ";
  cin >> p2;

  if((p1 == 1 && p2 ==1) || (p1 == 2 && p2 ==2) ||(p1 == 3 && p2 ==3)){
    cout << "Tie \n";
  }

  else if((p1 == 1 && p2 ==3) || (p1 == 2 && p2 ==1) ||(p1 == 3 && p2 ==2)){
    cout << "player 1 wins \n";
  }

  else if((p1 == 3 && p2 ==1) || (p1 == 1 && p2 ==2) ||(p1 == 2 && p2 ==1)){
    cout << "player 2 wins \n";
  }

  else{
    cout << "Invalid input \n";
  }

  return 0;
}

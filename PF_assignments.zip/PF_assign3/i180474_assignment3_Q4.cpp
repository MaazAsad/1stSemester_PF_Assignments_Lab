#include<iostream>
#include <limits>
using namespace std;

int main()
{

  char a;
  cout <<"Enter a character: ";
  cin >> a;

  cin.ignore(numeric_limits<streamsize>::max(), '\n');

  if((int(a) >=33 && int(a) <48)||(int(a) >=58 && int(a)<65) || (int(a) >=91 && int(a)<97) || (int(a)>=123))
  {
    cout << "Ints a special character." <<endl;
  }
  else if(int(a) >=48 && int(a)<58){
    cout << "Its a digit.";
  }
  else if(int(a) >= 65 && int(a) <91){
    cout << "Its a capital letter" << endl;
  }
  else if (int(a) >=97 && int(a) <123){
    cout <<"Its a lower case letter" << endl;
  }

  return 0;
}

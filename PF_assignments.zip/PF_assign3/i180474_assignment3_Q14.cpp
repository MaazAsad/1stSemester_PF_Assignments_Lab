#include<iostream>
#include <iomanip>

using namespace std;

int main()
{
  int p1, p2;

  cout << "Enter " << endl
       << "1 for rock"<<endl
       << "2 for paper" << endl
       << "3 for scissors" << endl << endl;

  cout << "player 1 turn: ";
  cin >> p1;
  cout << "player 2 turn: ";
  cin >> p2;

  switch(p1)
  {
    case 1:
          switch(p2){
            case 1:
                  cout << "Tie" << endl;
                  break;
            case 2:
                  cout << "Player 2 wins" << endl;
                  break;
            case 3:
                  cout << "Player 1 wins" << endl;
                  break;
            default :
                  cout << "Invalid input" << endl;
                  break;
          }
          break;

    case 2:
          switch(p2){
            case 1:
                cout << "Player 1 wins" << endl;
                break;
            case 2:
                cout << "Tie" << endl;
                break;
            case 3:
                cout << "Player 2 wins" << endl;
            break;
            default :
                cout << "Invalid input" << endl;
                break;
              }
            break;

    case 3:
          switch(p2){
            case 1:
                cout << "Player 2 wins" << endl;
                break;
            case 2:
                cout << "Player 1 wins" << endl;
                break;
            case 3:
                cout << "tie" << endl;
                break;
            default :
                cout << "Invalid input" << endl;
                break;
          }
          break;
    default:
          cout << "Invalid input" << endl;
  }


  return 0;
}

#include<iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main(){
  srand(time(NULL));
  int num1,num2,num3;
  num1 = rand()%10;
  num2 = rand()%10;
  num3 = rand()%10;

  //cout << num1<<endl<<num2 << endl<<num3 << endl;

  int g1,g2,g3;
  cout << "Guess three numbers (0-9): ";
  cin >> g1>>g2>>g3;

  if(g1  == num1)
  {
    if(g2 == num2 && g3 == num3){
      cout << "All correct and in order" << endl;
    }
    else if (g2 == num3 && g3 == num2){
      cout << "All correct but out of order"<< endl;
    }
    else if (g2 == num2 || g2 == num3 || g3 == num2 || g3 == num3){
      cout <<"Only 2 correct" << endl;
    }
    else{
      cout << "Only one correct" << endl;
    }

  }

  else if(g1  == num2)
  {
    if ((g2 == num1 && g3 == num3) || (g2 == num3 && g3 == num1)){
      cout << "All correct but out of order"<< endl;
    }
    else if (g2 == num1 || g2 == num3 || g3 == num1 || g3 == num3){
      cout <<"Only 2 correct" << endl;
    }
    else{
      cout << "Only one correct" << endl;
    }

  }

  else if(g1  == num3)
  {
    if ((g2 == num1 && g3 == num2) || (g2 == num2 && g3 == num1)){
      cout << "All correct but out of order"<< endl;
    }
    else if (g2 == num1 || g2 == num2 || g3 == num1 || g3 == num2){
      cout <<"Only 2 correct" << endl;
    }
    else{
      cout << "Only one correct" << endl;
    }

  }
  else{
    cout <<"Non of your guess were correct"<<endl;
  }



  return 0;
}

#include <iostream>
#include <cmath>
using namespace std;
int main() {

  int x1,y1, radius;
  int temp1, temp2, distance;
  int x2,y2;

  cout << "Enter the cordinates of centre of circle\n ";
  cout << "X= ";
  cin >>x1;

  cout  << "Y= ";
  cin >> y1;

  cout << "Enter radius of the circle: ";
  cin >> radius;
  
  cout <<"Enter cordinate to find if it lies in/on/out of the circle\n ";
  cout << "X= ";
  cin >> x2;

  temp1 = x2-x1;
  temp1 = pow(temp1,2);

  cout << "Y= ";
  cin >> y2;
  temp2 = y2-y1;
  temp2 = pow(temp2,2);

  distance = sqrt((temp1+temp2));

  if(distance == radius){
    cout <<"POint ("<< x2 << ", " << y2 <<") lies on  the circle"<<endl;
  }
  if(distance < radius){
    cout <<"POint ("<< x2 << ", " << y2 <<") lies inside  the circle"<<endl;
  }
  if(distance > radius){
    cout <<"POint ("<< x2 << ", " << y2 <<") lies outside  the circle"<<endl;
  }

  return 0;
}
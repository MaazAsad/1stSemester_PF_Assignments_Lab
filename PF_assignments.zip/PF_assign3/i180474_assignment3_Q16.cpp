#include<iostream>
#include<string>
using namespace std;

void burgerMenu(){
  cout <<"Enter 1 for Chicken patty burger 100 Rs\n"
       <<"      2 for Beef Burger 150 Rs \n"
       <<"      3 for Double Beef Burger 200 Rs \n"
       <<"      4 for Bison meat Burger 250Rs.\n";
}

void friesMenu(){
  cout <<"Enter 1 for Small Pack 25 Rs\n"
       <<"      2 for Medium Pack 50 Rs \n"
       <<"      3 for Large Pack 75 Rs \n"
       <<"      4 for Extra Large Pack 100Rs.\n";
}

void pizzaMenu(){
  cout <<"Enter 1 for Pepperoni Pizza (10 inches) 200 Rs\n"
       <<"      2 for Beef Pizza (10 inches) 250Rs \n"
       <<"      3 for Chicken Tikka Pizza (10 inches)  300Rs \n"
       <<"      4 for Combo pizza(3 in 1)(10 inches) 400Rs.\n";
}

void sandMenu(){
  cout <<"Enter 1 for Veg sandwich 50 Rs\n"
       <<"      2 for Chicken sandwich (2slicer) 100 Rs \n"
       <<"      3 for Chicken sandwich (4slicer) 150 Rs \n";
}


void userchoice(string x){
  cout <<"Enter A for 1" <<x << endl
       <<"Enter B for 2" << x<<"s" << endl
       <<"Enter C for 3" << x<<"s" << endl;
}

int main(){
  char tfood,quantity;
  int choice,price = 0;

  cout << "What would u like to order? \n"
       << "Enter B for burgers\n"
       << "      F for French fries \n"
       << "      P for Pizza\n"
       << "      S for Sandwiches\n";
  cin >> tfood;

  cout << "\n\n";
  switch (tfood) {
    case 'B':
          burgerMenu();
          cin >> choice;
          cout << "How many burgers will u like?\n";
          userchoice("Burger");
          cin >> quantity;
          switch(quantity){
            case 'A':
                    if (choice == 1){
                      price = 100;
                    }
                    if (choice == 2){
                      price = 150;
                    }
                    if (choice == 3){
                      price = 200;
                    }
                    if (choice ==4){
                      price = 250;
                    }

             case 'B':
                   if (choice == 1){
                     price = 100*2;
                   }
                   if (choice == 2){
                     price = 150*2;
                   }
                   if (choice == 3){
                     price = 200*2;
                   }
                   if (choice ==4){
                     price = 250*2;
                   }

             case 'C':
                   if (choice == 1){
                     price = 100*3;
                   }
                   if (choice == 2){
                     price = 150*3;
                   }
                   if (choice == 3){
                     price = 200*3;
                   }
                   if (choice ==4){
                     price = 250*3;
                   }

          }

          break;
    case 'F':
          friesMenu();cin >> choice;
          cout << "How many Packs of fries will u like?\n";
          userchoice("pack");
          cin >> quantity;
          switch(quantity){
            case 'A':
                    if (choice == 1){
                      price = 25;
                    }
                    if (choice == 2){
                      price = 50;
                    }
                    if (choice == 3){
                      price = 75;
                    }
                    if (choice ==4){
                      price = 100;
                    }

             case 'B':
                   if (choice == 1){
                     price = 25*2;
                   }
                   if (choice == 2){
                     price = 50*2;
                   }
                   if (choice == 3){
                     price = 75*2;
                   }
                   if (choice ==4){
                     price = 100*2;
                   }

             case 'C':
                   if (choice == 1){
                     price = 25*3;
                   }
                   if (choice == 2){
                     price = 50*3;
                   }
                   if (choice == 3){
                     price = 75*3;
                   }
                   if (choice ==4){
                     price = 100*3;
                   }

          }
          break;
    case 'P':
          pizzaMenu();
          cin >> choice;
          cout << "How many Pizzas will u like?\n";
          userchoice("Pizza");
          cin >> quantity;
          switch(quantity){
            case 'A':
                    if (choice == 1){
                      price = 200;
                    }
                    if (choice == 2){
                      price = 250;
                    }
                    if (choice == 3){
                      price = 300;
                    }
                    if (choice ==4){
                      price = 400;
                    }

             case 'B':
                   if (choice == 1){
                     price = 200*2;
                   }
                   if (choice == 2){
                     price = 250*2;
                   }
                   if (choice == 3){
                     price = 300*2;
                   }
                   if (choice ==4){
                     price = 400*2;
                   }

             case 'C':
                   if (choice == 1){
                     price = 200*3;
                   }
                   if (choice == 2){
                     price = 250*3;
                   }
                   if (choice == 3){
                     price = 300*3;
                   }
                   if (choice ==4){
                     price = 400*3;
                   }

          }

          break;
    case 'S':
          sandMenu();
          cin >> choice;
          cout << "How many sandwiches will u like?\n";
          userchoice("Sandwich");
          cin >> quantity;
          switch(quantity){
            case 'A':
                    if (choice == 1){
                      price = 500;
                    }
                    if (choice == 2){
                      price = 100;
                    }
                    if (choice == 3){
                      price = 150;
                    }

             case 'B':
                   if (choice == 1){
                     price = 500*2;
                   }
                   if (choice == 2){
                     price = 100*2;
                   }
                   if (choice == 3){
                     price = 150*2;
                   }


             case 'C':
                   if (choice == 1){
                     price = 500*3;
                   }
                   if (choice == 2){
                     price = 100*3;
                   }
                   if (choice == 3){
                     price = 150*3;
                   }

          }

          break;
    default:
        cout <<"Invalid input\n";
  }

  cout << "Total bill: " << price << endl;


  return 0;
}

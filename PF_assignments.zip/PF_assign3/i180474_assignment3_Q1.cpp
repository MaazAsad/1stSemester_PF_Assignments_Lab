#include<iostream>
using namespace std;

int main(){
  int num;
  cout << "Enter a number(1-20): ";
  cin >> num;

  if(num >= 1 && num <=20){
    cout << num << endl;
  }
  else{
    cout << "Not in range" << endl;
  }

  return 0;
}

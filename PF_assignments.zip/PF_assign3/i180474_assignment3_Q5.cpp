#include<iostream>
using namespace std;

int main()
{
  int gradeA,gradeB;

  cout << "Enter marks of major subject out of 100: ";
  cin >> gradeA;
  cout << "Enter marks of minor subject out of 100: ";
  cin >> gradeB;

  if(gradeA >= 55 && gradeB >= 45){
    cout << "Pass" <<endl;
  }
  else if(gradeA >= 45){
    if (gradeB >=55){
      cout << "Pass" <<endl;
    }
  }

  else if(gradeA >= 65 && gradeB <45){
    cout <<"Reappear in exams of minor." <<endl
  }

  else{
    cout <<"FAIL!" <<endl;
  }



  return 0;
}

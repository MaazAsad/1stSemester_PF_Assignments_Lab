#include<iostream>
using namespace std;

int main()
{
  char c1,c2;
  cout <<"y for Yellow" << endl
       <<"r for Red" << endl
       <<"b for Blue" << endl;
  cout <<"Enter 2 primary colors: ";
  cin >> c1 >> c2;

  if((c1 == 'r' && c2 == 'b') || (c1 == 'b' && c2 == 'r')){
    cout << "Purple" <<endl;
  }
  else if((c1 == 'r' && c2 == 'y') || (c1 == 'y' && c2 == 'r')){
    cout << "Orange" <<endl;
  }
  else if((c1 == 'y' && c2 == 'b') || (c1 == 'b' && c2 == 'y')){
    cout << "Green" <<endl;
  }
  else{
    cout <<"Invalid INPUT!" <<endl;
  }

  switch (c1) {
    case 'r':
            switch (c2) {
                    case 'b':
                            cout << "Purple" <<endl;
                            break;


                    case 'y':
                            cout <<"Orange" << endl;
                            break;
            }
            break;

    case 'b':
            switch(c2){
              case 'r':
                    cout << "Purple" << endl;
                    break;
              case 'y':
                    cout << "Green" << endl;
                    break;
            }
            break;


    case 'y':
            switch(c2){
              case 'r':
                      cout << "Orange" <<endl;
                      break;
              case 'b':
                      cout <<"Green" << endl;
                      break;
            }
            break;
    default:
          cout <<"Invalid INPUT!" <<endl;
  }




  return 0;
}

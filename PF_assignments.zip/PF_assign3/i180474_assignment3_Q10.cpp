#include<iostream>
#define PI 3.14159
using namespace std;

int main()
{ int choice;
  int radius,l,w,h;
  float area;
  cout << "Enter 1-4 " << endl;
       << "1 to calculate area of a circle" <<endl
       << "2 to calculate area of a rectangle" << endl
       << "3 to calcuate area of a triangle" << endl;
  cin >> choice;

  switch(choice){
    case 1:
          cout << "Enter radius of circle";
          cin >> radius;
          if(radius > 0){
            area = PI *radius * radius;
          }
          else{
            cout << "Invalid input!" <<endl;
          }
          break;

    case 2:
          cout << "Enter lenght of rectangle: ";
          cin >> l;
          cout << "Enter width of rectangle: ";
          cin >>w;
          if(l > 0 && w > 0){
            area =  l *w;
          }
          else{
            cout << "Invalid input";
          }
          break;

    case 3:
          cout << "Enter base of triangle: ";
          cin >> l;
          cout << "enter height of triangle: ";
          cin >> h;
          if(l > 0 && h > 0){
                area = 0.5 *l * h;
              }
          else {
            cout << "Invalid input! " << endl;
          }
          break;

    case 4:
        cout << "Exiting" << endl;
        break;

    default:
        cout << "Invalid input!" << endl;


  }

  return 0;
}

#include<iostream>
using namespace std;

int main()
{
  int booksbought, points=0;
  cout << "Enter number of books bought this month: ";
  cin >> booksbought;

  if (booksbought>=4){
    points = 60;
  }
  switch (booksbought) {
    case 3:
          points = 30;
          break;
    case 2:
          points =15;
          break;
    case 1:
          points = 5;
          break;
    case 0:
          points = 0;
          break;

  }


  cout << "You have earned " << points << " Points!" <<endl;
  return 0;
}

#include<iostream>
#include <iomanip>

using namespace std;

int main()
{ int usertime;

  cout << "Enter time in seconds: ";
  cin >> usertime;
  cout << setprecision(2) << fixed;
  if(usertime >= 86400){
    cout <<"No of days: " << (float(usertime)/86400) << endl;
  }

  else if(usertime >= 3600){
    cout <<"No of hours: "  << (float(usertime)/3600) << endl;
  }
  else if(usertime >= 60){
    cout <<"No of minutes: "  << (float(usertime)/60) << endl;
  }
  else if(usertime <60){
    cout << "No of seconds: " <<usertime << endl;;

  }
  else{
    cout << "Invalid input!" << endl;
  }



  return 0;
}

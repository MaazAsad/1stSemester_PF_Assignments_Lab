#include<iostream>
using namespace std;

int main()
{
  int days;
  cout << "Enter number of days: ";
  cin >> days;

  if(days >=30){
    cout << "Membership cancled." << endl;
  }
  else if(days >10){
    cout <<"You are fined 150 rupees" << endl;
  }
  else if (days >=6){
    cout << "you are fined 100 rupees" << endl;
  }
  else if (days == 5){
    cout << "Your are fined 50 rupees" << endl;
  }

  return 0;
}

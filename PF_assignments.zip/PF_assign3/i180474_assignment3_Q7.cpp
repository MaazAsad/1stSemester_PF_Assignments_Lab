#include<iostream>
using namespace std;

int main()
{
  int tensile,hardness,grade;
  float carboncont;

  cout <<"Enter hardness of steel: ";
  cin >> hardness;
  cout << "Enter carbon content: ";
  cin>> carboncont;
  cout << "Enter Tensile strength of steel: ";
  cin >> tensile;

  if(hardness > 50 && carboncont <0.7 && tensile > 5600 )
  {
    grade= 10;
  }
  else if(hardness > 50 && carboncont < 0.7)
  {
    grade = 9;
  }
  else if(carboncont < 0.7 && tensile > 5600){
    grade = 8;
  }
  else if(hardness > 50 && tensile > 5600){
    grade = 7;
  }
  else if (hardness > 50 || carboncont < 0.7 || tensile > 5600){
    grade = 6;
  }
  else{
    grade = 5;
  }



  cout << "This steel is graded " << grade << endl;


  return 0;
}

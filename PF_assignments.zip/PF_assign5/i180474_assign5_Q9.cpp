//lottery game
#include<iostream>
#include<random>
#include<time.h>
#include<string>
using namespace std;

int main(){
    const int size = 6;
    int lotteryarr[size];
    int userin[size];
    string mynum = " ";
    int count =0;

    srand(time(NULL));

    for(int i=0; i<size; i++){
        lotteryarr[i] = rand()%10;
    }

    // for(int i=0; i<size; i++){
    //     cout << lotteryarr[i];
    // }

    cout << endl;
    while(mynum.length() !=6){
        cout << "Enter your size 6 digitnumber: ";
        getline(cin, mynum);
        
    }

    for(int i=0; i<size; i++){
        userin[i] = int(mynum[i])-48;
        //cout << userin[i] << endl;
    }

    for(int i=0; i<size; i++){
        if(userin[i] == lotteryarr[i]){
            count ++;
        }

    }

    if(count == 6){
        cout << "Your are the grand prize winner" << endl;
    }
    else{
        cout <<"Better luck next time" << endl;
    }






    return 0;
}

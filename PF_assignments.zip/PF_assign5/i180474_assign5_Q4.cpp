#include<iostream>
using namespace std;

int main(){
    const int quarter = 4;
    const int divs =6;
    int company[divs][quarter];
    int num;
    int sum=0,prevsum=0;
    int dif =0;
    int heighestdiv;

    for(int i=0; i<divs; i++){
        cout <<"Division " <<i+1 << ": " <<endl;

        for(int j =0; j<quarter; j++){
            cout << "Quater " << j+1 <<": " ;
            num =-1;
            while(num < 0){
                cin >> num;
                if(num < 0){
                    cout << "Enter positive values please!"<<endl;
                }
            }
            company[i][j] = num;
            }

        cout << endl;
    }

    for(int i=0; i<divs; i++){
      sum =0;
      
      cout << "Sales by division " << i+1 << ": "<<endl;
      for(int j=0; j<quarter; j++){
        cout << "Quater " << j+1 <<": "<< company[i][j]<<endl;
        sum+=company[i][j];

        if(j!=0){
          if(company[i][j] > company[i][j-1]){
            dif = company[i][j] - company[i][j-1];
            cout << "Amount increase from previous quarter: "<<dif<<endl;
          }
          else if(company[i][j] < company[i][j-1]){
            dif = company[i][j-1] - company[i][j];
            cout << "Amount decrease from previous quarter: "<<dif<<endl;
          }      
        
        }


      }

      cout <<"Total sales by division "<< i+1<<": "<< sum<<endl;
      cout <<"Average sales by division: "<< i+1<<": "<< sum/quarter<<endl;

      if(sum>prevsum){
        heighestdiv =i;
        prevsum = sum;
      }


    }


    cout <<heighestdiv+1<<" made the most sales" << endl;







    return 0;
}

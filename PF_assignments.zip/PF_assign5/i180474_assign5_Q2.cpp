#include <iostream>
using namespace std;

int main(){
    const int size = 12;
    int month[size];
    int num;
    int max,min, sum=0;
    cout << "Enter rainfall for each month: "<<endl;
    for(int i =0; i<size; i++){
        num =-1;
        while(num < 0){
            cin >> num;
            if(num < 0){
                cout << "Enter positive values please!"<<endl;
            }
        }
        month[i] = num;
    }

    max = month[0];
    min = month[0];

    for(int i =0; i<size; i++){
        sum +=month[i];
        if(month[i]> max){
            max = month[i];
        }
        if(month[i] < min){
            min = month[i];
        }

    }


    cout << "total anual rainfall: " << sum << endl
         << "Average rainfall: " << (sum/size) << endl
         << "Max rainfall: " << max << endl
         << "Min rainfall: " <<min<<endl;


    return 0;
}

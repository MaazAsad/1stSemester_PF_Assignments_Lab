#include<iostream>

using namespace std;


int main(){
    int arr[] = {10,22,28,29,30,40};

    int sum,dif,smallestdif=9999999, x, a, b;
    int size =(sizeof(arr) / sizeof(*arr));


    cout <<"Enter x:";
    cin >> x;
    for(int i=0; i<size; i++){
        for(int j=i+1; j<size; j++){
            sum = arr[i] + arr[j];
            dif = x-sum;
            if(dif < smallestdif && dif > 0){
                a = arr[i];
                b = arr[j];
                smallestdif = dif;
            }
        }

    }

    cout << a <<" " << b<<endl;



    return 0;
}

#include<iostream>
using namespace std;

int main(){
    int arr[] = {27,15,15,11,14,27,11,11};
    int count =0,highestCount=0;
    int num = arr[0], repeated;

    for(int i=0; i < (sizeof(arr)/sizeof(*arr)); i++){
        count = 0;
        for(int j=0; j<(sizeof(arr)/sizeof(*arr)); j++){
            if(arr[i] == arr[j]){
                count++;
            }
        }

        if(count >= highestCount && arr[i]<= num){
            repeated = arr[i];
            num = arr[i];
            highestCount = count;
        }

    }


    cout << repeated <<endl;


    return 0;
}

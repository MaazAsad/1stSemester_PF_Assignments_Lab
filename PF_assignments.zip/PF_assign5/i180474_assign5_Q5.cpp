#include<iostream>

using namespace std;

int main(){
    cont int size=7;
    long int empId[] = {5658845,4520125,7895122,8777541,8451277,130285,7480489};
    int hours[size];
    double payrate[size],wages[size];
    int num;

    for(int i =0; i<size; i++){
        num =-1;
        cout << "Enter hours worked by Employee " << empId[i];
        while(num < 0){
            cin >> num;
            if(num < 0){
                cout << "Enter positive values please!"<<endl;
            }
        }
        hours[i] = num;
    }

    for(int i =0; i<size; i++){
        num =-1;
        cout << "Enter payrate of Employee " << empId[i];
        while(num < 6){
            cin >> num;
            if(num < 6){
                cout << "Enter correct pay rate"<<endl;
            }
        }
        payrate[i] = num;
    }

    for(int i=0; i<size; i++){
        wages[i] = hours[i]*payrate[i];
    }

    cout <<"Employee    :     wages" <<endl;
    for(int i=0; i< size; i++){
        cout << edmpId[i] << ": "<< wages[i] <<endl;
    }



    return 0;
}

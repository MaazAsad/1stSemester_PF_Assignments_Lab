#include<iostream>
using namespace std;

int main()
{
    const int size = 5;
    int arr[size];
    int temp, mid = size/2, prev_index=0;    
    int num;

    //input in array
    for(int i =0; i < size; i++){
        cin >> arr[i];
    }

    //sorting ascending order
    for(int i=0; i<size; i++){

        for(int j=0; j<size; j++){
            if(arr[i]<arr[j]){
                temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }

        }

    }

    //display array
    for(int i =0; i < size; i++){
        cout <<arr[i];
    }


    //binary search
    cout  << endl << "Enter number to search: ";
    cin >> num;
    while(true){
        if(arr[mid] == num){
            cout << "Element exists at " << mid << endl;
            break;
        }
        prev_index = mid;
        if(num > arr[mid]){
            mid = (mid+size)/2;
        }
        else if(num < arr[mid]){
            mid = mid/2;
        }
        if(prev_index == mid){
            cout << "Element not in array" << endl;
            break;
        }


    }

    return 0;
}

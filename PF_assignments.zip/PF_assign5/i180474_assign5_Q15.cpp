#include<iostream>
using namespace std;

int main(){
    const int size =7;
    int A[size], C[size];
    int count =0;
    int userin;

    for(int i=0; i<size; i++){
        userin =8;
        while(userin>6 || userin < 0){
            cout << "Enter value (0-6): ";
            cin >> userin;
        }

        A[i]= userin;
    }

    // for(int i=0;i<size;i++){
    //     cout << A[i]<<endl;
    // }

    for(int i=0;i<size;i++){
        count =0;
        for(int j=0;j<size;j++){
            if(i == A[j]){
                count++;
            }
        }

        C[i] = count;
    }

    for(int i=0;i<size;i++){
        cout <<i << ": "<< C[i]<<endl;
    }



    return 0;
}

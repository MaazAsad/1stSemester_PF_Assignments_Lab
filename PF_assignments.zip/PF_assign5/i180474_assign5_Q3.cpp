#include<iostream>
using namespace std;

int main(){
    const int m = 3;
    const int n = 2;
    int x[m],y[n],z[m+n];
    int temp;
    int c1 =(m-1), c2=(n-1);

    cout << "Enter values for array X: ";
    for(int i=0; i<m; i++){
        cin >>x[i];
    }
    for(int i=0; i<m; i++){
        for(int j=0; j<m; j++){
            if(x[i]<x[j]){
                temp = x[j];
                x[j] = x[i];
                x[i] = temp;
            }
        }
    }


    cout << "Enter valuse for array Y:";
    for(int i=0; i<n; i++){
        cin >> y[i];
    }
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            if(y[i]<y[j]){
                temp = y[j];
                y[j] = y[i];
                y[i] = temp;
            }
        }
    }


    cout << "X: { ";
    for(int i=0; i<m; i++){
        cout << x[i] <<" ";
    }
    cout <<"}"<<endl;


    cout << "Y: { ";
    for(int i=0; i<n; i++){
        cout << y[i] <<" ";
    }
    cout <<"}"<<endl;



    for(int i=0; i<(m+n); i++){

        if(x[c1]>y[c2] && c1!=-1){
            //cout<<"X: " << c1 << endl;
            z[i] = x[c1];
            c1--;
        }
        else{
            //cout << "Y: "<< c2<<endl;
            z[i] = y[c2];
            c2--;
        }

    }
    cout << "Z: { ";
    for(int i=0; i<(m+n); i++){
        cout << z[i] <<" ";
    }
    cout <<"}"<<endl;

    return 0;
}

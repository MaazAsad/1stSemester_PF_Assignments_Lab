#include<iostream>
#include<string>
using namespace std;

int main(){
    const int n=2;
    char arr[n];
    string temp;
    int x;
    cout <<"Enter " << n <<"chars: ";
    cin >> arr;
    cout <<"Enter X: ";
    cin >> x;
    string arr1[x*n] = {""};

    for(int i=0, k=1; i<x*n; k++){
        for(int j=0; j<n; j++){
            temp = arr[j];
            temp += char(k+48);
            //cout << temp<<endl;
            arr1[i]= temp;
            //cout << arr1[i]<<endl;
            i++;
        }
    }

    for(int i=0; i< x*n; i++){
        cout << arr1[i]<<endl;
    }


    return 0;
}

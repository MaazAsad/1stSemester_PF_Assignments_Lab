#include<iostream>
using namespace std;


int main(){
    const int size = 6;
    int arr[size];
    int newsize;
    int count = 0;
    for(int i =0; i<size; i++){
        cin >> arr[i];
        if(arr[i] >= 0){
            count++;
        }
    }
    newsize = size-count;
    int newarr[newsize];

    count =0;
    for(int i =0; i<size; i++){
        if(arr[i] < 0){
            newarr[count]= arr[i];
            count++;
        }
    }

    cout <<endl;

    for(int i=0;i<newsize; i++){
        cout << newarr[i] << " ";
    }




    return 0;
}

#include<iostream>
using namespace std;


int main(){
    int arr[]={10,22,28,29,30,40};
    int size= sizeof(arr)/sizeof(*arr);
    int arr2[size];
    int split;
    cin >>split;

    //cout << arr[split];
    for(int i=split, j=0;i<size; i++,j++){
        //cout << arr[i]<<endl;
        arr2[j] = arr[i];
    }

    for(int i=0, j=size-split; j<size; i++,j++){
        arr2[j] = arr[i];
    }

    for(int i=0;i<size; i++){
        cout << arr2[i] <<endl;
    }





    return 0;
}

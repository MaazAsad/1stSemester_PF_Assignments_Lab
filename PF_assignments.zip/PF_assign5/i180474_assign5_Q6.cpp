#include<iostream>
#include<string>
using namespace std;

int main(){
    string mystr;
    int start=0,end;
    int smallest = 999999, largest =-1;
    int count =0;
    string ls = "";
    string temp = "";
    string s2 = "";
    cout <<"Enter your string: ";
    getline(cin,mystr);

    for(int i=0; i<=mystr.length(); i++){
      cout << mystr[i]<<endl;
        if(mystr[i] != ' '|| mystr[i] == '\0'){
            count ++;
        }
        if(mystr[i] == ' ' || mystr[i] == '\0'){
            end = i;
            temp = "";
            if(count > largest){
                largest = count;
                for(int j=start; j<end;j++){
                  temp= temp + mystr[j];
                }
                ls = temp;
            }
            if(count < smallest){
                smallest = count;
                for(int j=start; j<end;j++){
                  temp += mystr[j];
                }
                s2 = temp;
            }

          start =i+1;
          count =0;

        }

    }

    cout << ls << endl << s2<<endl;



}

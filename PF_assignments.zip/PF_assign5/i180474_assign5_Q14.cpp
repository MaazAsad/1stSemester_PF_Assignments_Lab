#include<iostream>
#include<stdlib.h>
#include<time.h>
using namespace std;

int main(){
  srand(time(NULL));
  const int size =6;
  int arr[size],arr2[size];
  int x= rand()%size;
  int nsmall=0;
  int temp;
  int index =0,index2=0;
  cout <<"Enter values for array:";
  for(int i=0; i<size; i++){
    cin >> arr[i];
  }

  cout <<"Pivot: " <<arr[x]<<endl<<endl;

  for(int i=0;i<size;i++){
    if(arr[x]> arr[i]){
      nsmall+=1;
    }
  }
 // cout << "Smaler NUmbers: "<<nsmall<<endl;
  index2 = nsmall+1;
  if(nsmall!= x){
  temp = arr[x];
  arr[x] = arr[nsmall];
  arr[nsmall] = temp;
  }

  for(int i=0; i<size; i++){
    if(index == nsmall ||index == size){
      break;
    }
    if(arr[i]>arr[nsmall] && i != nsmall){
      temp = arr[index2];
      arr[index2] = arr[i];
      arr[i] = temp;
      index2++;
    }
    if(arr[i]<arr[nsmall] && i != nsmall){
      temp = arr[index];
      arr[index] = arr[i];
      arr[i] = temp;
      index++;
    }

  }

  for(int i=0; i<size; i++){
    cout << arr[i] <<" ";
  }
  cout <<endl;


  

  return 0;
}

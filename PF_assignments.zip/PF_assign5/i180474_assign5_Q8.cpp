// matrix multiplication using arrays
#include<iostream>
using namespace std;

int main(){
    const int r1=3,c1=3, r2=3,c2 =4;
    int mat1[r1][c1];
    int mat2[r2][c2];
    int mat3[r1][c2];
    int sum =0;

    if(c1 == r2){

        cout << "Enter values for Matrix 1:"<<endl;
        for(int i=0; i<r1;i++){

            cout <<"Row "<<i+1 << ": ";
            for(int j=0; j<c1; j++){
                cin >> mat1[i][j];
            }
        }

        cout << "Enter values for Matrix 2:"<<endl;
        for(int i=0; i<r2;i++){

            cout <<"Row "<<i+1 << ": ";
            for(int j=0; j<c2; j++){
                cin >> mat2[i][j];
            }
        }

        cout <<"Matrix 1" <<endl;
        for(int i=0; i<r1; i++){
            for(int j=0; j<c1; j++){
                cout << mat1[i][j] << " ";
            }
            cout << endl;
        }

        cout <<"Matrix 2" <<endl;
        for(int i=0; i<r2; i++){
            for(int j=0; j<c2; j++){
                cout << mat2[i][j] << " ";
            }
            cout << endl;
        }


        for(int i=0; i<r1; i++){
            for(int j=0; j<c2; j++){
                sum =0;
                for(int k=0; k<c1; k++){
                    //cout << mat1[i][k]<<" " << mat2[k][j] << endl;
                    //cout << (mat1[i][k] * mat2[k][j]) << endl;
                    sum += (mat1[i][k] * mat2[k][j]);
                    //cout << sum << " ";
                }
                mat3[i][j] = sum;
            }
        }

        cout <<endl<<"Matrix 3" <<endl;
        for(int i=0; i<r2; i++){
            for(int j=0; j<c2; j++){
                cout << mat3[i][j] << " ";
            }
            cout << endl;
        }




    }
    else{
        cout << "Martix cannot be multiplied" << endl;
    }





    return 0;
}

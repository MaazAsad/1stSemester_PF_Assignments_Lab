#include<iostream>
using namespace std;

int main(){
    const int r=5, c=2;
    int arr[r][c];
    int temp;

    for(int i =0;i<r; i++){
        cout << "Row "<< i+1 << endl;
        for(int j=0; j<c; j++){
            cin >> arr[i][j];
        }
    }

    for(int i=0;i<r; i++){
        for(int j=0; j<r; j++){
            if(arr[i][c-1] < arr[j][c-1]){
                temp = arr[i][c-1];
                arr[i][c-1] = arr[j][c-1];
                arr[j][c-1] = temp;

                temp = arr[i][0];
                arr[i][0] = arr[j][0];
                arr[j][0] = temp;
            }
        }
    }

    for(int i=0 ; i<r; i++){
        for(int j =0; j<c; j++){
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }


    return 0;
}

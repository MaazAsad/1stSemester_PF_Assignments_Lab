#include<iostream>
using namespace std;

int main(){
    const int size = 20;
    char ans[20]={'A','C','A','A','D','B','C','A','C','B','A','D','C','A','D','C','B','B','D','A'};
    char myans[20];
    int count =0;

    cout <<"Enter Answers (A,B,C or D): ";
    for(int i=0; i<size; i++){
        cout << "Q"<< i+1<< ": ";
        cin >> myans[i];

        if(int(myans[i]) >= 97 && int(myans[i])<=122){
            myans[i] = char(int(myans[i])-32);
        }

        if(myans[i] == ans[i]){
            count++;
        }

    }

    if(count >=15){
        cout <<"You have passed the test!"<<endl;
    }
    else{
        cout <<"Better luck next time!"<<endl;
    }


    return 0;
}

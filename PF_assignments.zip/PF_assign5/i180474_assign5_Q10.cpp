#include<iostream>
#define size 3
using namespace std;

void menu(){
    cout << "Enter 1: Total of all values in matrix" << endl
         << "      2: Average of all values in matrix" << endl
         << "      3: Total of values in a specific row" << endl
         << "      4: Total of values in a specific column" << endl
         << "      5: Highest value in a specifi row" << endl
         << "      6: lowest value in a specific row" << endl
         << "      7: Transpose of matrix "<<endl
         << "      8: sum of Left diagonal" << endl
         << "      9: sum of right diagonal" <<endl
         << "     10: Multiply with another matrix"<<endl;
 }

 void matrixInput(int (*arr)[size][size]){

     for(int i=0; i<size;i++){
         cout <<"Row "<<i+1 << ": ";
         for(int j=0; j<size; j++){
             cin >> (*arr)[i][j];
         }
     }
 }

 void matrixPrint(int (*arr)[size][size]){

     for(int i=0; i<size;i++){
         for(int j=0; j<size; j++){
             cout<< (*arr)[i][j] << " ";
         }
         cout << endl;
     }
 }

void total(int* sum, int arr[][size]){
    for(int i=0; i <size; i++){
        for(int j=0; j<size; j++){
            *sum += arr[i][j];
        }
    }

}

void average(int* sum){
    cout <<"Average = " << *sum/(size*size) <<endl;
}

void rowTotal(int* sum, int arr[][size],int x){
    for(int i=0;i<size;i++){
        *sum += arr[x][i];
    }
}

void colTotal(int* sum, int arr[][size],int x){
    for(int i=0;i<size;i++){
        *sum += arr[i][x];
    }
}

void heighest(int* h, int arr[][size],int x){
    *h=arr[x][0];
    for(int i=0; i<size; i++){
        if(arr[x][i]> *h){
            *h = arr[x][i];
        }
    }
}

void lowest(int* h, int arr[][size],int x){
    *h=arr[x][0];
    for(int i=0; i<size; i++){
        if(arr[x][i]< *h){
            *h = arr[x][i];
        }
    }
}

void transpose(int (*arr)[size][size], int (*arr2)[size][size]){
    for(int i=0;i<size;i++){
        for(int j=0; j<size; j++){
            //cout << (*arr)[i][j]<<endl;

            (*arr2)[i][j] = (*arr)[j][i];
        }
    }

}

void leftDiagonalSum(int *sum, int (*arr)[size][size]){
    for(int i=0; i<size;i++){
        for(int j=0; j<size; j++){
            if(i==j){
                *sum+= (*arr)[i][j];
            }
        }
    }
}

void rightDiagonalSum(int *sum, int (*arr)[size][size]){
    for(int j=size-1; j>=0;j--){
        for(int i=0; i<size; i++){
            if(i==j){
                //cout << (*arr)[i][j];
                *sum+= (*arr)[i][j];
            }
        }
    }
}

void matrixMultiply(int (*arr)[size][size],int (*arr2)[size][size],int (*arr3)[size][size]){
    int sum=0;
    for(int i=0; i<size; i++){
        for(int j=0; j<size; j++){
            sum =0;
            for(int k=0; k<size; k++){
                //cout << (*arr)[i][k]<<" " << (*arr2)[k][j] << endl;
                sum += (*arr)[i][k] * (*arr2)[k][j];
            }
            (*arr3)[i][j] = sum;
        }
    }
}

int main(){

    int mat1[size][size];
    int mat2[size][size] = {-1};
    int mat3[size][size] = {-1};
    int sum=0;
    int num=4;
    int heigh,low,choice;

    //input into matrix
    cout << "Enter values for Matrix:"<<endl;
    matrixInput(&mat1);

    cout << endl;

    menu();
    cout <<"Matrix 1: "<<endl;
    matrixPrint(&mat1);
    cout << endl << "Option: ";
    cin >> choice;

    switch (choice) {
        case 1:
            total(&sum, mat1);
            cout << "Sum of all values: " << sum <<endl;
            break;

        case 2:
            total(&sum, mat1);
            average(&sum);
            break;

        case 3:
            while(num>3){
                cout <<"Enter row number: ";
                cin >> num;
            }
            rowTotal(&sum,mat1,num-1);
            cout << "Sum of values in row "<< num << ": "<<sum<<endl;
            break;

        case 4:
            while(num>3){
                cout << "Enter column number: ";
                cin >> num;
            }
            colTotal(&sum,mat1,num-1);
            cout << "Sum of values in column "<< num << ": "<<sum<<endl;
            break;

        case 5:
            while(num>3){
                cout <<"Enter row number: ";
                cin >> num;
            }
            heighest(&heigh,mat1,num-1);
            cout << "heights of value in row "<< num << ": "<<heigh<<endl;
            break;

        case 6:
            while(num>3){
                cout <<"Enter row number: ";
                cin >> num;
            }
            lowest(&low,mat1,num-1);
            cout << "lowest of value in row "<< num << ": "<<low<<endl;
            break;

        case 7:
            transpose(&mat1,&mat2);
            for(int i=0;i<size; i++){
                for(int j=0; j<size; j++){
                    cout << mat2[i][j] << " ";
                }
                cout << endl;
            }
            break;

        case 8:
            leftDiagonalSum(&sum, &mat1);
            cout <<"Sum of left Diagonal: "<< sum << endl;
            break;

        case 9:
            rightDiagonalSum(&sum, &mat1);
            cout <<"Sum of right Diagonal: "<< sum << endl;
            break;

        case 10:
            cout << "Enter values for 2nd Matrix:"<<endl;
            matrixInput(&mat2);

            cout <<"Frist Matrix: "<<endl;
            matrixPrint(&mat1);

            cout <<"Second Matrix: "<<endl;
            matrixPrint(&mat2);

            matrixMultiply(&mat1, &mat2, &mat3);

            cout <<"Result: "<<endl;
            matrixPrint(&mat3);
            break;

        default:
            cout << "Invalid input " <<endl;
            break;
    }
    return 0;
}

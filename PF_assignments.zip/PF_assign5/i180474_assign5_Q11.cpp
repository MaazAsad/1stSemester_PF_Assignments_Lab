#include<iostream>
#include<string>
#define maxSize 256
using namespace std;

void menu(){
    cout << "Enter 1: Length of string" << endl
         << "      2: Number of words in string" << endl
         << "      3: Check for Palindrome" << endl
         << "      4: Find a word in array" << endl
         << "      5: To Lower Case" << endl
         << "      6: To Upper case" << endl;
 }

int inputLen(string a){
    int count=0;
    for(int i=0;;i++){
        if(a[i] == '\0'){
            break;
        }
        else{
            count++;
        }
    }
    return count;

}

int nWords(string a){
    int count=0;
    for(int i=0; ;i++){
        if(a[i] == ' ' || a[i] == '\0'){
            count ++;
        }
        if(a[i] == '\0'){
            break;
        }
    }

    return count;

}

void palindrome(string a){
    string b="";
    for(int i = 1; i<=inputLen(a);i++){
        b+= a[inputLen(a)-i];
    }

    if(a == b){
        cout <<"Is a palindrome"<<endl;
    }
    else{
        cout <<"Not a palindrome"<<endl;
    }

}

void findWord(string a, string b){

    int start=0;
    int end =0;
    bool found = false;
    string word="";


    for(int i=0; i <= inputLen(a);i++){
        word="";
        if(a[i] == ' ' || a[i] == '\0'){
            end = i;
            for(int j= start; j<end;j++){
                word += a[j];
            }
            //cout << word << endl;;

            if(word == b){
                cout << "Start position of word: " << start;
                found = true;
                break;
            }

            start =i+1;

        }

        if(a[i] == '\0' && found == false){
            cout << "Word not in string"<<endl;
            break;
        }

    }
}

void lowerCase(string a){
    for(int i=0; i<inputLen(a);i++){
        if( int(a[i]) >=65 && int(a[i]) <= 91){
            a[i] = char(int(a[i]+32));
        }
    }

    cout << a<<endl;

}

void upperCase(string a){
    for(int i=0; i<inputLen(a);i++){
        if( int(a[i]) >=97 && int(a[i]) <= 122){
            a[i] = char(int(a[i]-32));
        }
    }

    cout << a<<endl;

}


int main(){
    int count =0;
    int choice;
    string userin,find;

    cout <<"Enter your string: ";
    getline(cin,userin);
    //cin.ignore(1,'\n');
    //cout <<userin <<endl;

    menu();
    cin >>choice;
    switch (choice) {
        case 1:
            inputLen(userin);
            break;
        case 2:
            nWords(userin);
            break;
        case 3:
            palindrome(userin);
            break;
        case 4:
            cout <<"Enter word to search: ";
            cin.ignore(80,'\n');
            getline(cin,find);
            findWord(userin,find);
            break;
        case 5:
            lowerCase(userin);
            break;
        case 6:
            upperCase(userin);
            break;

        default:
            cout << "Invaild option" << endl;
            break;
    }

    return 0;
}

#include<iostream>
#include<string>
using namespace std;

int main(){
    const int size = 5;
    int count =0,c1 =0;
    string arr[size];
    string arr2[size] = {""};

    for(int i=0; i<size; i++){
        cout <<"Enter String "<<i+1 <<": ";
        getline(cin,arr[i]);
    }

    // for(int i=0; i<size; i++){
    //     cout <<arr[i]<<endl;
    // }

    for(int i=0; i<size;i++){
        for(int j=arr[i].length(); j>=0; j--){
            arr2[i]+= arr[i][j];
        }
    }

    // for(int i=0; i<size; i++){
    //     cout <<arr2[i]<<endl;
    // }

    for(int i=0; i<size; i++){
        c1 =0;
        for(int j=0; j<arr[i].length(); j++){
            //cout << arr[i][j] << " " << arr2[i][j+1]<<endl;
            if(arr[i][j] == arr2[i][j+1]){
                c1++;
            }
        }
        // cout << i <<" " << c1<<endl;

        if( arr[i].length()>=2 && c1 == arr[i].length()){
            count ++;
        }
    }

    cout <<count << endl;

}

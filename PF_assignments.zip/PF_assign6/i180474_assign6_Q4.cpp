#include<iostream>
#include<cmath>

using namespace std;


int sqr(int x){
    return x*x;
}

void sort(int arr[], int size){
    int temp;

    for(int i=0; i<size; i++){
        for(int j=0; j<size;j++){
            if(arr[i]> arr[j]){
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}


float mean(int arr[], int size){
    float sum =0.0;
    for(int i=0; i<size; i++){
        sum += arr[i];
    }

    return sum/size;
}

int median(int arr[], int size){
    sort(arr,size);
    if(size%2 == 0){
        return arr[size/2];
    }
    else{
        return arr[(size+1)/2];
    }

}

int mod(int arr[], int size){
    int count =0;
    int max=0;
    int temp;
    for(int i=0; i<size; i++){
        count =0;
        for(int j=0; j<size; j++){
            if(arr[i] == arr[j]){
                count++;
            }
        }

        if(count > max){
            max= count;
            temp = arr[i];
        }
    }

    return temp;
}

float standard_devi(int arr[], int size){
    float sum =0.0;
    int avg = mean(arr,size);
    float sd;

    for(int i=0; i<size; i++){
        sum += sqr(arr[i]-avg);
    }

    sd = sqrt(sum/size);

    return sd;
}


int main(){
    int size = 11;
    int data[size] = {5,6,4,3,7,8,1,10,20,15,1};

    cout <<"Mean: " << mean(data, size)<<endl;
    cout <<"Median: " << median(data, size)<<endl;
    cout <<"Mod: " << mod(data, size) << endl;
    cout <<"Standard Deviation: " << standard_devi(data, size)<<endl;


    return 0;
}

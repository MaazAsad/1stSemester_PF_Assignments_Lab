#include<iostream>
#include<ctime>
#include<stdlib.h>
using namespace std;
const int size =3;

void initTable(char arr[][size]){
    for(int i =0; i<size; i++){

        for(int j=0; j<size; j++){
            arr[i][j] = ' ';

        }

    }

}

void printtable(char arr[][size]){
    for(int i =0,a=0; i<size+2; i++){

        if(i%2 == 0){

            for(int j=0,k =0; j<size+2; j++){
                if(j%2 == 0){
                    cout << arr[a][k];
                    k++;
                }
                else{
                    cout << "|";

                }


            }
            cout << endl;
            a++;
        }

        else{
            for(int j=0; j<size+2; j++){
                cout << "-";
            }
            cout << endl;
        }
    }

}

bool checkEmpty(char arr[][size], int a, int b){
    if(arr[a][b] == ' '){
        return true;
    }
    else{
        return false;
    }
}

bool checkin(int a, int b){
    if(a>=0 && a<3 && b>=0 && b<3){
        return true;
    }
    else{
        return false;
    }
}

bool tableFull(char table[][size]){
    int count =0;

    for(int i=0; i<size; i++){
        for(int j=0; j<size; j++){
            if(table[i][j] != ' '){
                count++;
            }
        }
    }

    if(count == 9){
        return true;
    }
    else{
        return false;
    }
}

bool checkRow(char table[][size], char x){
    int count;

    for(int i=0; i<size; i++){
        count =0;
        for(int j=0; j<size; j++){
            if(table[i][j] == x){
                count++;
            }
        }

        if(count ==3){
            return true;

        }
    }

    return false;
}

bool checkCol(char table[][size], char x){
    int count;

    for(int i=0; i<size; i++){
        count =0;
        for(int j=0; j<size; j++){
            if(table[j][i] == x){
                count++;
            }
        }

        if(count ==3){
            return true;

        }
    }

    return false;
}

bool checkDiag(char table[][size], char x){
    int count=0;
    for(int i=0; i<size; i++){
        if(table[i][i] == x){
            count ++;
        }
    }

    if(count == 3){
        return true;
    }
    else{
        return false;
    }
}

bool checkAntiDiag(char table[][size], char x){
    int count =0;
    for(int i=0, j=size-1; i<size; i++,j--){
        if(table[i][j] == x){
            count++;
        }        
    }
    if(count ==3){
        return true;
    }
    else{
        return false;
    }
}

void userTurn(int *a,int *b){
    bool flag = false;
    while(!flag){
        cout <<"Enter where to place mark"<<endl;
        cin >> *a >> *b;
        flag = checkin(*a, *b);
    }
}

void pcTurn(int *a, int *b) {
    *a = rand()%3;
    *b = rand()%3;
}


int main(){
    srand(time(NULL));
    char table[size][size], userChar, pcChar;
    int r,c;
    bool empty = false;

    cout << "Chose your character (O or X):";
    cin >> userChar;
    if(userChar == 'X'){
        pcChar = 'O';
    }
    else{
        pcChar = 'X';
    }

    initTable(table);
    printtable(table);

    while(true){
        //user turn
        empty =false;
        while(!empty){
            userTurn(&r, &c);
            empty = checkEmpty(table, r, c);
        }
        table[r][c] = userChar;

        if(checkRow(table, userChar) || checkCol(table, userChar) || checkDiag(table, userChar) || checkAntiDiag(table, userChar) ){
            printtable(table);
            cout<<endl << "Player Wins!"<<endl;
            break;
        }


        if(tableFull(table)){
            cout << "Game is Draw!"<<endl;
            break;
        }
        //pc turn
        empty = false;
        while(!empty){
            pcTurn(&r, &c);
            empty = checkEmpty(table, r, c);
        }
        table[r][c] = pcChar;

        if(checkRow(table, pcChar) || checkCol(table, pcChar) || checkDiag(table, pcChar) || checkAntiDiag(table, pcChar) ){
            printtable(table);
            cout<<endl << "PC Wins!"<<endl;
            break;
        }




        printtable(table);


    }
    return 0;
}

#include<iostream>
#include<cmath>
using namespace std;

const int row = 3;
const int col =2;

int sumSquares(int arr[][col], char a);
int sum(int arr[][col], char a);
int sumProducts(int arr[][col]);


int main(){
    int testdata [row][col] = { {1,2}, {5,6}, {8,9} };
    float numerator,denom,temp1,temp2,r;

    int xsum = sum(testdata,'x');
    int ysum = sum(testdata, 'y');

    int xsquare = sumSquares(testdata, 'x');
    int ysquare = sumSquares(testdata, 'y');

    int xy = sumProducts(testdata);

    // cout << xsum << endl << ysum << endl;   //14 //17
    // cout << xsquare << endl << ysquare << endl; //90  //119
    // cout << xy << endl; //104

    numerator = (xy - (xsum*ysum));
    //cout << numerator <<endl;   //-134

    temp1 = row * xsquare;
    temp1 = temp1- (xsum * xsum); // 74

    temp2 = row * ysquare;
    temp2 = temp2-(ysum * ysum); //74


    denom = sqrt(float(temp1)*temp2); // 74

    r = numerator/denom; //-1.81

    cout << r << endl;

    return 0;
}


int sum(int arr[][col], char a){
    int sum = 0;
    int cordinate;
    if(a == 'x'){
        cordinate = 0;
    }
    if(a == 'y'){
        cordinate = 1;
    }
    for(int i = 0; i<row; i++){
        sum += arr[i][cordinate];
    }

    return sum;

}

int sumSquares(int arr[][col], char a){

    int sum = 0;
    int cordinate;
    if(a == 'x'){
        cordinate = 0;
    }
    if(a == 'y'){
        cordinate = 1;
    }
    for(int i = 0; i<row; i++){
        sum += (arr[i][cordinate] * arr[i][cordinate]);
    }

    return sum;

}

int sumProducts(int arr[][col]){
    int sum =0;
    for(int i=0; i<row; i++){
        sum += (arr[i][0] * arr[i][1]);
    }

    return sum;
}

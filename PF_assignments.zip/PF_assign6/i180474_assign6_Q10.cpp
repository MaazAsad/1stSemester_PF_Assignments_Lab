#include<iostream>
using namespace std;

float mysin(float);
float power(float,int);
float factorial(float);

int main(){
    float num;
    cout <<"Enter Number: ";
    cin >> num;

    //num = num * (3.142/180);

    cout << "Sin(" << num << ") = "<< mysin((num* (3.142/180)))<<endl;


    return 0;

}


float mysin(float a){
    float res =0;
    int x=1;

    for(int i = 0; i<6; i++){
        if(i%2 == 0){
            //cout << i << " " <<power(a,x) << " " << factorial(x)<<endl;
            res += (power(a,x)/ factorial(x));
        }
        else{
            //cout << i << " " <<power(a,x) << " " << factorial(x)<<endl;
            res -= (power(a,x)/ factorial(x));
        }
        x+=2;
    }
    return res;
}

float power(float a, int b){
    if(b ==0 || b ==1){
        return a;
    }
    return a*power(a,b-1);
}

float factorial(float a){
    if(a==0 || a==1){
        return 1;
    }
    return a*factorial(a-1);
}

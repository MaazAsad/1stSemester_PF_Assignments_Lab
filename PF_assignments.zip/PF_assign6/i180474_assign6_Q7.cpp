#include<iostream>
#define size 5
using namespace std;

void linearsearch(int arr[], int a);

void binarySearch(int arr[], int a);

void sortarr(int arr[]);


int main(){
    int data[size] = {5,4,-1,6,3};

    linearsearch(data , 6);
    cout << endl;
    binarySearch(data, 6);
}


void linearsearch(int arr[], int a){
    bool nopos = false, found = false;
    int neg;
    for(int i=0; i<size; i++){
        if(arr[i] == a){
            found = true;
            cout <<"Element exists at index "<< i<<endl;
            break;
        }
        if(arr[i] < 0){
            neg = arr[i];
            nopos = true;
        }
    }
    if(nopos == true && found == false){
        cout << neg<<endl;
    }
    else if(nopos == false && found == false){

        cout << "No Number found"<<endl;
    }
}

void binarySearch(int arr[], int a){
    int mid =size/2;
    int neg, prev_index;
    bool nopos = false ,found = false;
    sortarr(arr);
    cout << "Sorted array:"<<endl;

    for(int i=0; i<size; i++){
        cout << arr[i]<<endl;
    }

    while(true){
        //cout << mid<<endl;

        if(arr[mid] == a){
            cout << "Element exists at index " << mid << endl;
            found = true;
            break;
        }

        if(arr[mid]< 0){
            neg = arr[mid];
            nopos = true;
        }
        prev_index = mid;

        if(a > arr[mid]){
            mid = (mid+size)/2;
        }
        else if(a < arr[mid]){
            mid = mid/2;
        }

        if(prev_index == mid){
            break;
        }
    }

    if(nopos == true && found == false){
        cout << neg<<endl;
    }
    else if(nopos == false && found == false){

        cout << "No Number found"<<endl;
    }

}




void sortarr(int arr[]){
    int temp;
    for(int i=0; i<size; i++){
        for(int j=0; j< size; j++){
            if(arr[i]<arr[j]){
                temp = arr[j];
                arr[j]=arr[i];
                arr[i]= temp;
            }
        }
    }

}

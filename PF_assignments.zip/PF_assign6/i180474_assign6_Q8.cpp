#include<iostream>
using namespace std;
const int row = 4;
const int col = 5;

void rotateleft(int arr[col]){
    int temp = arr[0];
    for(int i=0; i< col-1; i++){
        arr[i] = arr[i+1];
    }
    arr[col-1] = temp;
}


int main(){
    int testdata[row][col]={
                            {1,2,3,4,5},
                            {11,12,13,14,15},
                            {6,7,8,9,10},
                            {21,22,23,24,25},
                        };

    for(int i =0; i<row; i++){
        rotateleft(testdata[i]);
        rotateleft(testdata[i]);
    }

    cout << endl;

    for(int i=0; i<row; i++){
        for(int j=0; j<col; j++){
            cout << testdata[i][j] << ", ";
        }
        cout << endl;
    }
    return 0;
}

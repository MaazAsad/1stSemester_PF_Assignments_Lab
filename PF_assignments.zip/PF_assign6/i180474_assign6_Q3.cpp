#include<iostream>
#include<string>
using namespace std;


int stringlenght(string a){
    int count =0;
    for(int i=0; a[i] != '\0'; i++){
        count ++;
    }
    return count;
}

string rev(string a){
    char temp;
    for(int i =0; i<stringlenght(a)/2; i++){
        temp = a[i];
        a[i] = a[stringlenght(a)-1-i];
        a[stringlenght(a)-1-i] = temp;
    }

    return a;
}

string decToBin(int num){
    string x ="";

    while(num !=0){
        x += char(num%2+48);
        num = num/2;
    }
    x = rev(x);
    return x;
}

int main(){
    int num;

    cout << "Enter Number to convert innto Binary: ";
    cin >> num;

    cout << decToBin(num)<<endl;


    return 0;
}

#include<iostream>
#include<cmath>
using namespace std;

const int row= 3;
const int col = 3;

float norm(int arr[row][col]){
    float sum = 0;

    for(int i=0; i<row; i++){

        for(int j=0; j<col; j++){

            sum += (arr[i][j] * arr[i][j]);

        }
    }

    return sqrt(sum);

}


int main(){
    int data[row][col] = {{1,2,3}, {4,5,6}, {7,8,9}};

    cout << norm(data)<<endl;

    return 0;

}

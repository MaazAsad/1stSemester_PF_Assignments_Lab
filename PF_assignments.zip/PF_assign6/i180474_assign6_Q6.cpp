#include<iostream>
#include<cmath>
using namespace std;


void inPut(int arr[]){
    cout << "X: ";
    cin >> arr[0];
    cout << "Y: ";
    cin >> arr[1];
    cout << endl;
}

float len(int arr1[],int arr2[]){
    float dis1 = ( (arr1[0]-arr2[0]) * (arr1[0]-arr2[0]) ) + ( (arr1[1]-arr2[1]) *(arr1[1]-arr2[1] ) );
    dis1 =  sqrt(dis1);
    return dis1;
}

float areaofT(float a, float b, float c){
    float s = (a+b+c)/2;
    s = sqrt((s*(s-a)*(s-b)*(s-c)));
    return s;
}

void setOrigin(int arr1[], int arr2[]){
    arr1[0] -= arr2[0];
    arr1[1] -= arr2[1];
}

int inTriangle(float a, float b, float c){
    if(a<1 && b<1 && c<1){
        return 1;
    }
    else{
        return 0;
    }
}


int main(){
    int A[2],B[2],C[2], P[2];
    float dis1, dis2,dis3, area;
    float x,y;
    float wA, wB, wC, d;

    cout << "Enter cordinates of A: "<<endl;
    inPut(A);

    cout << "Enter cordinates of B: "<<endl;
    inPut(B);

    cout << "Enter cordinates of C: "<<endl;
    inPut(C);

    dis1 = len(A,B);
    dis2 = len(A,C);
    dis3 = len(B,C);

    area = areaofT(dis1, dis2, dis3);
    cout << "Area of triangle: "<< area<<endl<<endl;

    cout << "Enter cordinates to check:";
    cout << "X: ";
    cin >>P[0];
    cout << "Y: ";
    cin >> P[1];
    cout << endl;

    setOrigin(B,A);
    setOrigin(C,A);
    setOrigin(P,A);

    d = B[0]*C[1] - C[0]*B[1];

    x= C[0]-B[0];
    y = B[1]-C[1];

    wA = ( P[0]*y + P[1]*x + d ) / d;

    wB = ( P[0]*C[1]- P[1]*C[0])/d;

    wC = (P[1]*B[0] - P[0]*B[1])/d;

    cout << wA << endl << wB << endl << wC <<endl;


    if(inTriangle(wA, wB, wC)){
        cout << "Point (" << P[0]+A[0] << "," << P[1]+A[1] << ") lies in triangle" << endl;
    }
    else{
        cout << "Point (" << P[0]+A[0] << "," << P[1]+A[1] << ") lies outside triangle" << endl;
    }
    cout << endl;

    return 0;
}

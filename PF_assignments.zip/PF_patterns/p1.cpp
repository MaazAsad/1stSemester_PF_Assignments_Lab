#include<iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter Num: ";
    cin >> n;
    for(int i = 0; i <n;i++){

        for(int x = 0;x <i;x ++){
            cout << " ";
        }
        cout << "*" << endl;

    }

    for(int i = n; i > 0; i--){

        for(int x = i; x > 0; x--){
            cout << " ";
        }
        cout << "*" << endl;
    }

    return 0;
}

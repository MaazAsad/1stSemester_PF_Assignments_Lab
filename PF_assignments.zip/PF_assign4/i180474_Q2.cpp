#include<iostream>
#include<cmath>
using namespace std;

int main(){
    int sum=0, num;
    int count =0;
    float average;
    char a = 'y';

    while(a =='y' or a == 'Y'){
        count +=1;
        cout <<"Enter students score: ";
        cin >> num;
        sum += num;
        cout << "Do u want to enter more numbers(Y/N): ";
        cin >> a;
    }

    average = float(sum)/count;

    cout << endl <<"Average score: " << average<<endl;
    return 0;
}

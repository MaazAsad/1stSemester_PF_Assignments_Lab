#include<iostream>
#include<cmath>
#include<string>
using namespace std;

void reverseStr(string& str)
{
    int n = str.length();
    
    for (int i = 0; i < n / 2; i++)
        swap(str[i], str[n - i - 1]);
}


int main()
{
    string binnum;

    int temp = 0;
    int result = 0;

    cout << "Enter Number: ";
    cin >> binnum;
    cin.ignore(100,'\n');

    reverseStr(binnum);

    //cout << binnum << endl;
    //cout << binnum.length() <<endl;

    for(int i = 0; i < binnum.length(); i++){
        temp = (int(binnum[i])-48) * (pow(2,(i)));
        //cout << temp << endl;
        result += temp;
    }

    cout << result;





    return 0;
}

#include<iostream>
#include<iomanip>
using namespace std;

int main(){
    int bar;

    for(int i = 0; i < 5; i++){
        cin >> bar;
        for(int j = 0; j < bar; j++){
            cout << "*";
        }
        cout << endl;
    }

    return 0;
}

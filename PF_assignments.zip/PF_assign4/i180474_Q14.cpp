#include<iostream>
using namespace std;

int main(){
    int spaces = 1;
    int lines;
    cin >> lines;
    int tri = lines -1;
    int mid = (lines *2)-2;
    int reverse = 0;


    for(int i = 0; i < lines; i ++){

        for(int j = 0; j < tri; j++){
            cout << "*";
        }

        for(int j = 0; j < spaces; j ++){
            cout << " ";
        }

        for(int j = 0; j < mid; j++){
            cout << "\\";
        }

        for(int j = 0; j < reverse; j++){
            cout << "/";
        }
        for(int j = 0; j < spaces; j ++){
            cout << " ";
        }

        for(int j = 0; j < tri; j++){
            cout << "*";
        }

        spaces +=1;
        tri -=1;
        mid -=2;
        reverse +=2;
        cout << endl;
    }




    return 0;
}

#include<iostream>
using namespace std;
int main(){
    int num = 1;
    for(int i= 1 ; i <= 30; i ++){
        if(i %10 ==0){
            cout <<"|";

        }
        else{
            cout << " ";
        }
    }

    cout << endl;

    for(int i= 0 ; i < 30; i ++,num++/*n++ should be removed it num +=1 is being used*/){
        if(num == 10){
            num = 0;
        }
            cout << num;//num +=1;
    }
    return 0;
}

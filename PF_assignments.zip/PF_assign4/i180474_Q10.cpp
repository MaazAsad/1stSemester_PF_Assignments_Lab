#include<iostream>
using namespace std;
int main()
{
    int lines;
    cin >> lines;
    int spaces = 0;

    for(int i =0; i < lines; i ++){
        cout << "*";
        for(int j = 0; j < spaces; j++){
            cout << " ";
        }
        cout << "*";
        spaces += 1;
        cout << endl;
    }
    return 0;
}

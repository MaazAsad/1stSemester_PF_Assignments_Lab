#include<iostream>
using namespace std;

int main(){
    int m,n, remain;
    cout << "Enter values of M and N: ";
    cin >> m >> n;

    while(n !=0){
         remain = m%n;
         m = n;
         n = remain;
    }

    cout << "Greatest common devisior: " << m << endl;





    return 0;
}

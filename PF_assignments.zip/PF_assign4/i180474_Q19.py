def main():
    lines = int(input("Enter number of lines: "))
    spaces = lines -1

    for i in range(lines):

        for j in range(spaces):
            print " ",

        for j in range(i+1):
            print j+1,

        for j in range(i,0,-1):
            print j,

        print("\n")
        spaces -=1

    spaces +=2

    for i in range(lines):

        for j in range(spaces):
            print " ",

        for j in range(lines-spaces):
            print j+1,

        spaces +=1
        print "\n"

if __name__ == "__main__":
    main()

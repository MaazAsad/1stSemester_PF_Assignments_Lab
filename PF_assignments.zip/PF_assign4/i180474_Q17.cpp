#include<iostream>
#include<cmath>
using namespace std;

int main()
{
    int num = 1, deno = 2;
    int terms;
    cin >> terms;
    for(int i = 0; i < terms; i++){
        cout << num << "/" << deno <<", ";
        num += (pow(2, i+1));
        deno +=(pow(2, i+1));
    }



    return 0;
}

#include<iostream>
using namespace std;

int main()
{
    int num;
    int sum = 0;
    int reverse = 0;
    int temp;

    cout << "Enter Number: ";
    cin >> num;

    while(num !=0){
        temp = num%10;
        sum += temp;
        reverse = reverse * 10 + temp;
        num /= 10;
    }

    cout << "Reverse: " << reverse << " Sum: " << sum << endl;




    return 0;
}

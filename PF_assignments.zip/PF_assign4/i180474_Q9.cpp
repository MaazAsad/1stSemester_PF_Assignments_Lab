#include<iostream>
using namespace std;
int main()
{
    int lines;
    cin >> lines;
    int spaces = 0;
    int mark = 4*lines -2;
    for(int i =0; i < lines; i++){
        for(int j = 0; j < spaces; j++){
            cout << '\\';
        }
        for(int j = 0; j < mark; j++){
            cout << "!";
        }
        for(int j = 0; j < spaces; j++){
            cout << "/";
        }
        mark -= 4;
        spaces += 2;
        cout << endl;
    }
    return 0;
}

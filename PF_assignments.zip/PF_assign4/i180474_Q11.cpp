#include<iostream>
using namespace std;
int main(){
    int lines;
    cin >> lines;
    int spaces = lines -1;
    for(int i = 0; i < lines; i ++){

        for(int j = 0; j < spaces; j++){
            cout << " ";
        }

        for(int j = 0; j < i+1; j++){
            cout << i+1;
        }
        spaces -= 1;
        cout << endl;
    }
    return 0;
}

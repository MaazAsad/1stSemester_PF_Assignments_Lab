#include<iostream>
using namespace std;
int main(){

    for(int i = 0; i < 40; i ++){
        cout << "-";
    }
    cout << endl;

    for(int i = 0; i < 40; i++){
        if(i %2 != 0){
            cout << "-";
        }
        if(i%2 == 0){
            if(i%4 == 0){
                cout << " ";
            }
            else{
                cout << "^";
            }
        }
    }
    cout << endl;
    for(int i = 0; i < 40; i ++){
        if(i%4 == 0){
            cout << "_";
        }
        else{
            cout << " ";
        }
    }
    cout << endl;

    int num = 1;
    for(int i= 0 ; i < 20; i ++,num++/*n++ should be removed it num +=1 is being used*/){
        if(num == 10){
            num = 0;
        }
        for(int j=0; j < 2; j++){
            cout << num;
        }
        //num +=1;
    }
    cout << endl;

    for(int i = 0; i <40; i ++){
        cout <<"-";
    }
    cout << endl;


    return 0;
}

#include<iostream>
#include<cmath>
using namespace std;

int main(){
    int minimum = 9999999;
    int minx,miny;
    int result, temp1, temp2, xsqr;
    for(int x = -10000; x < 10000; x++){

        for(int y = -10000; y<10000; y++){
            temp1 = 1-x;
            temp1 = temp1*temp1;
            xsqr = x*x;
            temp2 = y-xsqr;
            temp2 = temp2*temp2;

            result = temp1+ 100*temp2;

            if(result < minimum){
                minimum = result;
                minx = x;
                miny = y;
            }


        }

    }

    cout << "Minimun value of Function: "<<minimum << endl;
    cout << minx << endl<< miny;

    return 0;
}

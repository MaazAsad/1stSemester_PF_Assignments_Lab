#include<iostream>
#include <math.h>
using namespace std;

int main(){
    float pi = 4.0;
    int count =1, i = 3;
    cout <<"Terms       PI"<<endl;
    cout <<count<<"           "<<pi<<endl;
    while(true){
        count +=1;
        if(count >1 && (count%2) ==0){
            pi -= (float(4)/i);
        }
        if(count >1 && (count%2!=0)){
            pi += (float(4)/i);
        }
        pi = roundf(pi * 1000) / 1000;

        cout <<count<<"           "<<pi<<endl;
        i+=2;
        if(int(pi*100) == 314){
             break;
        }
    }

    return 0;
}

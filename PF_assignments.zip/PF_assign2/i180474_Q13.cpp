/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
#include<cmath>
using namespace std;

int main(){
  int t;
  float interest, principal, rate;

  cout << "Enter Principal ammount: ";
  cin >> principal;

  cout << "Enter Interest rate: ";
  cin >> rate;

  cout << "Enter Times cumpounded: ";
  cin >> t;

/*  // formula for interest can be simplified into
I = (Prt)/100
where P = principal ammount
      r = interestrate
      T = times compounded

*/interest = principal * (rate/100) * (t/12.00);

  cout << "Interest Rate: " << rate <<endl
       << "Time Compounded: " << t << endl
       << "Principal: " << principal <<endl
       << "Interest: " << interest << endl
       << "Amount Savings: " << (principal + interest) <<endl;



  return 0;
}

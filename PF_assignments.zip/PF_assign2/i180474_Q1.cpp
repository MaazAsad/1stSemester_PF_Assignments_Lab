/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;

int main(){
  int a, b,c ;

  cout << "Enter 3 numbers: " << endl;

  cin >> a >> b >> c;

  float average = (a+b+c)/3.0;

  cout << "Average: " << average << endl;

  return 0;
}

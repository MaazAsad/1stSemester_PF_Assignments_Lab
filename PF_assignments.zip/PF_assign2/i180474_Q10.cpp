/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;

int main(){
  float ammount , statetax, countytax, totaltax;

  cout << "Enter ammount:";
  cin >> ammount;

  statetax = 0.05* ammount;
  countytax = 0.025 * ammount;

  totaltax = statetax + countytax;

  cout << "Ammount: " <<ammount<<endl
       << "State sales tax: " << statetax<<endl
       << "County sales tax:" << countytax << endl
       << "Total Tax: " << totaltax << endl
       << "Total Sale ammount: " << (ammount + totaltax)<<endl;

       return 0;
}

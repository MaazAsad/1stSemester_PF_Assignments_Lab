/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;


int main(){
  char x;
  cout <<"Enter a capital letter: ";
  cin >> x;

  char y = char((int(x) + 32));

  cout << "Corresponding lower case letter: " << y << endl;


  return 0;
}

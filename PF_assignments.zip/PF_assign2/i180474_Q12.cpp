/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
#include <iomanip>
#include<cmath>

#define PI 3.142

using namespace std;
int main(){
   float rad;

   cout << "Enter angle in radians: ";
   cin >> rad;
   cout << setprecision(4)<<fixed;
   cout << "Sine of " << rad << " is "<<sin(rad) <<  endl
       << "Cosine of " << rad << " is " <<cos(rad) << endl
       << "Tangent of " << rad << " is " << tan(rad) << endl;


   return 0;
 }

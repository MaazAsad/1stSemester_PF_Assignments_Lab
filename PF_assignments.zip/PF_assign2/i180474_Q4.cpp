/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
#define PI 3.1428
using namespace std;


int main(){
  int radius;
  float circum;

  cout << "Enter radius: ";
  cin >> radius;

  circum = 2 * PI *radius;

  cout << "Circumference: " << circum<< endl;


  return 0;
}

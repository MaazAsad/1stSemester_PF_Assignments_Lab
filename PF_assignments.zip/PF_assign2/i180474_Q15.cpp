/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
#define PI 3.1428
using namespace std;

int main(){
  int slices,diameter;
  float area;

  cout << "Enter Diameter of Pizza: ";
  cin >> diameter;

  area = PI * (float(diameter)/2) * (float(diameter)/2);

  slices = area /14.125;

  cout << "Number of slices: " << slices << endl;
  return 0;
}

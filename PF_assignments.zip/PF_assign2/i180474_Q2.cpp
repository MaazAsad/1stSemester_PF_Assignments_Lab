/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
#include<cmath>
using namespace std;

int main()
{
  int a,b,c;
  cout << "enter sides of a triangle: ";
  cin >> a >> b >> c;
  float area,semi,x;

  semi = (a+b+c)/2;
  x = semi* (semi-a) * (semi-b)* (semi-c);
  area = sqrt(x);

  cout << "Area: " << area << endl;

  return 0;
}

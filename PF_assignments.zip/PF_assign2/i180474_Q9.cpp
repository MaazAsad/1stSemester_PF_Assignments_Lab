/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;

int main(){
  int feet,inches;
  float centimeters;

  cout << "Enter feets: ";
  cin >> feet;
  cout <<"Enter inches: ";
  cin >> inches;

  inches += (feet*12);

  centimeters = inches *2.54;

  cout << "Length in centimeters: " << centimeters <<endl;
  return 0;
}

/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
#include<string>
using namespace std;

int main(){
  string fname,lname, age,petname,pettype,cityname,profession,college;


  cout << "Enter first name: ";
  getline(cin,fname);
  cout << "Enter last name: ";
  getline(cin,lname);
  cout << "Enter name of city you live in: ";
  getline(cin,cityname);
  cout << "enter age: ";
  getline(cin, age);



  cout << "Enter your profession: ";
  getline(cin, profession);
  cout << "Which college did you go to? ";
  getline(cin,college);

  cout << "A pet? ";
  getline(cin, pettype);
  cout << "Its name? ";
  getline(cin, petname);

  cout << "There once was a person named " << fname << " "  << lname <<" who lived in "
       <<cityname << ". At the age of " << age << ", "<<fname << " went to college at "
       <<college << ". "<<fname <<" graduated and went to work as a " << profession <<". "
       <<" Then, "<<fname<<" adopted a(n) "<<pettype << " named "<< petname <<". They both lived happily ever after" <<endl;

  return 0;
}

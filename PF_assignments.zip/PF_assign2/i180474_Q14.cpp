/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
 #include <iomanip>
#include<cmath>
using namespace std;

int main(){
  float rate, Lamount, Npayments,Mpay, paidback,interest,Mrate,temp;
  float x;

  cout << "Enter Loan Ammount: ";
  cin >> Lamount;

  cout << "Enter Annual interest Rate: ";
  cin >> rate;
  Mrate = rate/12;
  cout << "Enter Number Of Payments: ";
  cin >> Npayments;

  x = (1.0 + Mrate);

  x = pow(x,Npayments);

  //cout << x;

  Mpay = (Mrate*x) / (x-1) * Lamount;

  //cout << Mpay;

   paidback = Lamount;

   //cout << paidback <<endl;
  for(int i = 0; i < 12; i++){
    temp = paidback * (Mrate/100);
    paidback += temp;

  }
  // cout << paidback;
  interest = paidback - Lamount;
  // cout << endl << interest;

  cout << "Loan Amount: " << Lamount << endl
       << "Monthly Interest Rate: " <<std::setprecision(3)<<Mrate << endl;
  cout << "Number of Payments: " << Npayments <<endl;
  cout << "Monthly Payment: "<<std::setprecision(5) << Mpay << endl;
  cout << "Amount Paid Back: "<<std::setprecision(5) << paidback << endl;
  cout << "Interest Paid: " <<std::setprecision(5)<<interest <<endl;


  return 0;
}

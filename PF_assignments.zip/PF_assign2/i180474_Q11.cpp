/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;

int main(){
  float loan,insurance,gas,oil,tires,maintenance,total;
  cout << "Enter monthly expenses of automobile on: "<<endl;
  cout << "Loan: ";
  cin >> loan;
  cout << "Insurance: ";
  cin >> insurance;
  cout << "Gas: ";
  cin >> gas;
  cout << "Oil: ";
  cin >> oil;
  cout << "Tires: ";
  cin >> tires;
  cout << "maintenance: ";
  cin >> maintenance;
  total = (loan + insurance + gas +oil + tires + maintenance);
  cout << endl <<endl;

  cout << "Total MOnthly cost : " << total << endl
       << "Total Anual cost: " << total *12 <<endl;
  return 0;
}

/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;

int main(){
  int ammount,n500,n100,n50,n20,n10,n5,n1;

  cout << "Enter Ammount: ";
  cin >> ammount;


  n500 = ammount/ 500;
  ammount -= (500*n500);

  n100 = ammount / 100;
  ammount -= (100 * n100);

  n50 = ammount / 50;
  ammount -= (50 * n50);

  n20 = ammount / 20;
  ammount -= (20* n20);

  n10 = ammount / 10;
  ammount -= (10* n10);

  n5 = ammount /5;
  ammount -= (5*n5);

  n1 = ammount /1;
  ammount -= (n1*1);

  cout << "500: " << n500 << endl
       << "100: " << n100 << endl
       << "50: "  << n50 << endl
       << "20: "  << n20 << endl
       << "10: "  << n10 << endl
       << "5: "   << n5 << endl
       << "1: "   << n1 << endl;

  return 0;
}

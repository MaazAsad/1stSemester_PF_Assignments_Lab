/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;

int main(){
  int num, sum = 0,digit;
  cout << "Enter Number:";
  cin >> num;

  for(int i = 0; i <4; i++){
    digit = num %10;
    sum += digit;
    num /= 10;

  }

  cout << "Sum: " <<sum << endl;

  return 0;
}

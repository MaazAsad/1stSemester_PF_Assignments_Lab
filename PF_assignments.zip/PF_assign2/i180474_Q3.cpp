/*
Name : Maaz Asad
Roll No. 18I-0474
Section: C
*/
#include<iostream>
using namespace std;

int main(){
  int a,b;
  cout << "Enter 2 numbers: ";
  cin >> a >>b;

  cout << "Sum: " << (float(a)+b) <<endl
       << "Difference: " << (float(a)-b) << endl
       << "Product: " << float(a)*b << endl;
  if (b == 0){
    cout << "Quotient: Undefined"<<endl;
    cout << "Remainder: Undefined"<<endl;
  }
  else{
    cout << "Quotient: " << a/b << endl;
    cout << "Remainder: " << a%b << endl;
  }

  return 0;
}
